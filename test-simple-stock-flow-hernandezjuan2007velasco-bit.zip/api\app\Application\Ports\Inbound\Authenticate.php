<?php

declare(strict_types=1);

namespace App\Application\Ports\Inbound;

use App\Application\DTOs\AuthResultDTO;

/**
 * Puerto de Entrada (Inbound): Autenticación y registro de nuevos vendedores.
 * Implementado por UseCases\AuthenticationService.
 */
interface Authenticate
{
    public function login(string $username, string $password): AuthResultDTO;

    public function registerSeller(string $username, string $password, string $role): string;
}
