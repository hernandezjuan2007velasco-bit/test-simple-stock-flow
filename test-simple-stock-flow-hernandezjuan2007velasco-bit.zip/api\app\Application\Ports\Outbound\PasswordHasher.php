<?php

declare(strict_types=1);

namespace App\Application\Ports\Outbound;

/**
 * Puerto Saliente: Servicio de Hash de Contraseñas.
 */
interface PasswordHasher extends PasswordHasherInterface
{
}
