<?php

declare(strict_types=1);

namespace Tests\Architecture;

use PHPUnit\Framework\TestCase;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;

final class ArchitectureRulesTest extends TestCase
{
    /**
     * R-01: Domain no debe importar nada de Illuminate ni del framework.
     */
    public function test_domain_does_not_import_illuminate(): void
    {
        $domainPath = __DIR__ . '/../../app/Domain';
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($domainPath));

        foreach ($iterator as $file) {
            if ($file->isFile() && $file->getExtension() === 'php') {
                $content = file_get_contents($file->getPathname());
                $this->assertStringNotContainsString(
                    'Illuminate\\',
                    $content,
                    "Violación R-01: El archivo {$file->getFilename()} en Domain contiene referencias a Illuminate."
                );
            }
        }
    }

    /**
     * R-03: Presentation no debe importar Infrastructure.
     */
    public function test_presentation_does_not_import_infrastructure(): void
    {
        $presentationPath = __DIR__ . '/../../app/Presentation';
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($presentationPath));

        foreach ($iterator as $file) {
            if ($file->isFile() && $file->getExtension() === 'php') {
                $content = file_get_contents($file->getPathname());
                $this->assertStringNotContainsString(
                    'App\\Infrastructure',
                    $content,
                    "Violación R-03: El archivo {$file->getFilename()} en Presentation contiene importación de Infrastructure."
                );
            }
        }
    }
}
