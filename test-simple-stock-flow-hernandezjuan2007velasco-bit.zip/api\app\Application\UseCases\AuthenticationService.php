<?php

declare(strict_types=1);

namespace App\Application\UseCases;

use App\Application\DTOs\AuthResultDTO;
use App\Application\Ports\Inbound\Authenticate;

/**
 * Servicio de Aplicación para autenticación y registro de nuevos vendedores.
 * Implementa el puerto Inbound Authenticate.
 */
final class AuthenticationService implements Authenticate
{
    public function __construct(
        private readonly AuthenticateUserUseCase $authenticateUserUseCase,
        private readonly RegisterSellerUseCase $registerSellerUseCase
    ) {}

    public function login(string $username, string $password): AuthResultDTO
    {
        return $this->authenticateUserUseCase->execute($username, $password);
    }

    public function registerSeller(string $username, string $password, string $role): string
    {
        return $this->registerSellerUseCase->execute($username, $password, $role);
    }
}
