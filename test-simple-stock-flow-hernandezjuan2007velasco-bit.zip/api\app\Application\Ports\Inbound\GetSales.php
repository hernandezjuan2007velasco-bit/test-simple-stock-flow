<?php

declare(strict_types=1);

namespace App\Application\Ports\Inbound;

use App\Application\DTOs\PagedResultDTO;
use App\Application\DTOs\SaleViewDTO;
use App\Domain\ValueObjects\DateRange;

/**
 * Puerto de Entrada (Inbound): Consulta de ventas históricas y comprobante de venta.
 * Implementado por UseCases\GetSalesService.
 */
interface GetSales
{
    public function listSales(DateRange $range, int $page, int $size): PagedResultDTO;

    public function getDetails(string $id): SaleViewDTO;
}
