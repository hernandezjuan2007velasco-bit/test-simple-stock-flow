<?php

declare(strict_types=1);

namespace App\Application\Ports\Inbound;

use App\Application\DTOs\CreateProductDTO;
use App\Application\DTOs\PagedResultDTO;
use App\Application\DTOs\ProductViewDTO;
use App\Application\DTOs\UpdateProductDTO;

/**
 * Puerto de Entrada (Inbound): Mantenimiento y consulta del catálogo de productos y categorías.
 * Implementado por UseCases\ProductCatalogService.
 */
interface ManageProducts
{
    public function create(CreateProductDTO $dto): ProductViewDTO;

    public function update(string $id, UpdateProductDTO $dto): ProductViewDTO;

    public function softDelete(string $id): void;

    public function attachImage(string $id, string $fileContent, string $extension): void;

    public function listCatalog(?string $search, ?string $categoryId, int $page, int $size): PagedResultDTO;

    public function getById(string $id): ProductViewDTO;

    public function listCategories(): array;
}
