<?php

declare(strict_types=1);

namespace App\Application\Ports\Outbound;

/**
 * Puerto Saliente: Almacenamiento de Binarios / Archivos.
 */
interface FileStorage extends FileStorageInterface
{
}
