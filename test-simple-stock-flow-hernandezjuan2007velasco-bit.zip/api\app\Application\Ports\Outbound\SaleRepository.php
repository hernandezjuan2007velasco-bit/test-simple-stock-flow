<?php

declare(strict_types=1);

namespace App\Application\Ports\Outbound;

/**
 * Puerto Saliente: Repositorio de Ventas.
 */
interface SaleRepository extends SaleRepositoryInterface
{
}
