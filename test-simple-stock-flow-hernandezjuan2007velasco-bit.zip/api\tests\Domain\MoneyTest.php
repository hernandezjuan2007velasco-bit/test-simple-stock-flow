<?php

declare(strict_types=1);

namespace Tests\Domain;

use App\Domain\Exceptions\InvalidPriceException;
use App\Domain\ValueObjects\Money;
use PHPUnit\Framework\TestCase;

final class MoneyTest extends TestCase
{
    public function test_can_create_positive_money(): void
    {
        $money = Money::of(1500.50);
        $this->assertSame(1500.50, $money->amount());
        $this->assertSame('COP', $money->currency());
    }

    public function test_negative_money_throws_exception(): void
    {
        $this->expectException(InvalidPriceException::class);
        Money::of(-50.0);
    }

    public function test_addition_of_money(): void
    {
        $m1 = Money::of(100.0);
        $m2 = Money::of(250.50);
        $sum = $m1->plus($m2);

        $this->assertSame(350.50, $sum->amount());
    }
}
