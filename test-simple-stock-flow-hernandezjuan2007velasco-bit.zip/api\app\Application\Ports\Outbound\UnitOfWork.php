<?php

declare(strict_types=1);

namespace App\Application\Ports\Outbound;

/**
 * Puerto Saliente: Unidad de Trabajo Transaccional.
 */
interface UnitOfWork extends UnitOfWorkInterface
{
}
