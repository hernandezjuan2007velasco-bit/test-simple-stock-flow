<?php

declare(strict_types=1);

namespace App\Bootstrap;

use App\Application\Ports\Inbound;
use App\Application\Ports\Outbound;
use App\Application\UseCases;
use App\Infrastructure\Persistence\Repositories\DatabaseSalesReportQuery;
use App\Infrastructure\Persistence\Repositories\DatabaseUnitOfWork;
use App\Infrastructure\Persistence\Repositories\EloquentCategoryRepository;
use App\Infrastructure\Persistence\Repositories\EloquentProductRepository;
use App\Infrastructure\Persistence\Repositories\EloquentSaleRepository;
use App\Infrastructure\Persistence\Repositories\EloquentUserRepository;
use App\Infrastructure\Services\Argon2PasswordHasher;
use App\Infrastructure\Services\JwtTokenGenerator;
use App\Infrastructure\Services\LocalFileStorage;
use App\Infrastructure\Services\SystemClock;
use Illuminate\Support\ServiceProvider;

/**
 * Composition Root del sistema: único proveedor autorizado para conectar implementaciones
 * de infraestructura con los puertos de aplicación.
 */
final class PortBindingsServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // 1. Enlace de Puertos Salientes (Outbound Interfaces)
        $this->app->singleton(Outbound\ClockInterface::class, SystemClock::class);
        $this->app->singleton(Outbound\Clock::class, SystemClock::class);

        $this->app->singleton(Outbound\PasswordHasherInterface::class, Argon2PasswordHasher::class);
        $this->app->singleton(Outbound\PasswordHasher::class, Argon2PasswordHasher::class);

        $this->app->singleton(Outbound\FileStorageInterface::class, LocalFileStorage::class);
        $this->app->singleton(Outbound\FileStorage::class, LocalFileStorage::class);

        $this->app->singleton(Outbound\TokenGeneratorInterface::class, JwtTokenGenerator::class);
        $this->app->singleton(Outbound\TokenGenerator::class, JwtTokenGenerator::class);

        $this->app->singleton(Outbound\UnitOfWorkInterface::class, DatabaseUnitOfWork::class);
        $this->app->singleton(Outbound\UnitOfWork::class, DatabaseUnitOfWork::class);

        $this->app->singleton(Outbound\CategoryRepositoryInterface::class, EloquentCategoryRepository::class);
        $this->app->singleton(Outbound\CategoryRepository::class, EloquentCategoryRepository::class);

        $this->app->singleton(Outbound\ProductRepositoryInterface::class, EloquentProductRepository::class);
        $this->app->singleton(Outbound\ProductRepository::class, EloquentProductRepository::class);

        $this->app->singleton(Outbound\SaleRepositoryInterface::class, EloquentSaleRepository::class);
        $this->app->singleton(Outbound\SaleRepository::class, EloquentSaleRepository::class);

        $this->app->singleton(Outbound\UserRepositoryInterface::class, EloquentUserRepository::class);
        $this->app->singleton(Outbound\UserRepository::class, EloquentUserRepository::class);

        $this->app->singleton(Outbound\SalesReportQueryInterface::class, DatabaseSalesReportQuery::class);
        $this->app->singleton(Outbound\SalesReportQuery::class, DatabaseSalesReportQuery::class);

        // 2. Enlace de Puertos Entrantes (Inbound Interfaces)
        $this->app->bind(Inbound\ManageProducts::class, UseCases\ProductCatalogService::class);
        $this->app->bind(Inbound\PlaceSale::class, UseCases\RegisterSaleUseCase::class);
        $this->app->bind(Inbound\GetSales::class, UseCases\GetSalesService::class);
        $this->app->bind(Inbound\GetSalesReport::class, UseCases\GetSalesReportUseCase::class);
        $this->app->bind(Inbound\Authenticate::class, UseCases\AuthenticationService::class);
    }
}
