<?php

declare(strict_types=1);

namespace App\Application\Ports\Inbound;

use App\Application\DTOs\SalesReportDTO;
use App\Domain\ValueObjects\DateRange;

/**
 * Puerto de Entrada (Inbound): Generación de reporte agregado de ventas por rango de fechas.
 * Implementado por UseCases\GetSalesReportUseCase.
 */
interface GetSalesReport
{
    public function execute(DateRange $range): SalesReportDTO;
}
