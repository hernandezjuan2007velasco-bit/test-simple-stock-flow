<?php

declare(strict_types=1);

namespace App\Application\Ports\Outbound;

/**
 * Puerto Saliente: Generador y Validador de Tokens JWT.
 */
interface TokenGenerator extends TokenGeneratorInterface
{
}
