<?php

declare(strict_types=1);

namespace App\Application\Ports\Outbound;

/**
 * Puerto Saliente: Consulta Agregada del Reporte de Ventas.
 */
interface SalesReportQuery extends SalesReportQueryInterface
{
}
