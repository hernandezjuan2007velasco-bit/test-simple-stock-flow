<?php

declare(strict_types=1);

namespace App\Application\UseCases;

use App\Application\DTOs\PagedResultDTO;
use App\Application\DTOs\SaleViewDTO;
use App\Application\Ports\Inbound\GetSales;
use App\Domain\ValueObjects\DateRange;

/**
 * Servicio de Aplicación para consulta de ventas históricas y comprobante de venta.
 * Implementa el puerto Inbound GetSales.
 */
final class GetSalesService implements GetSales
{
    public function __construct(
        private readonly ListSalesUseCase $listSalesUseCase,
        private readonly GetSaleDetailsUseCase $getSaleDetailsUseCase
    ) {}

    public function listSales(DateRange $range, int $page, int $size): PagedResultDTO
    {
        return $this->listSalesUseCase->execute($range, $page, $size);
    }

    public function getDetails(string $id): SaleViewDTO
    {
        return $this->getSaleDetailsUseCase->execute($id);
    }
}
