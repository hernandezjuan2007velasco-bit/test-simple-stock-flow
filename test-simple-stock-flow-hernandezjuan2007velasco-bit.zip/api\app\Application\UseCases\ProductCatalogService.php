<?php

declare(strict_types=1);

namespace App\Application\UseCases;

use App\Application\DTOs\CreateProductDTO;
use App\Application\DTOs\PagedResultDTO;
use App\Application\DTOs\ProductViewDTO;
use App\Application\DTOs\UpdateProductDTO;
use App\Application\Ports\Inbound\ManageProducts;

/**
 * Servicio de Aplicación para mantenimiento y consulta del catálogo.
 * Implementa el puerto Inbound ManageProducts.
 */
final class ProductCatalogService implements ManageProducts
{
    public function __construct(
        private readonly CreateProductUseCase $createProductUseCase,
        private readonly UpdateProductUseCase $updateProductUseCase,
        private readonly SoftDeleteProductUseCase $softDeleteProductUseCase,
        private readonly AttachProductImageUseCase $attachProductImageUseCase,
        private readonly GetProductCatalogUseCase $getProductCatalogUseCase,
        private readonly GetProductByIdUseCase $getProductByIdUseCase,
        private readonly GetCategoriesUseCase $getCategoriesUseCase
    ) {}

    public function create(CreateProductDTO $dto): ProductViewDTO
    {
        return $this->createProductUseCase->execute($dto);
    }

    public function update(string $id, UpdateProductDTO $dto): ProductViewDTO
    {
        return $this->updateProductUseCase->execute($id, $dto);
    }

    public function softDelete(string $id): void
    {
        $this->softDeleteProductUseCase->execute($id);
    }

    public function attachImage(string $id, string $fileContent, string $extension): void
    {
        $this->attachProductImageUseCase->execute($id, $fileContent, $extension);
    }

    public function listCatalog(?string $search, ?string $categoryId, int $page, int $size): PagedResultDTO
    {
        return $this->getProductCatalogUseCase->execute($search, $categoryId, $page, $size);
    }

    public function getById(string $id): ProductViewDTO
    {
        return $this->getProductByIdUseCase->execute($id);
    }

    public function listCategories(): array
    {
        return $this->getCategoriesUseCase->execute();
    }
}
