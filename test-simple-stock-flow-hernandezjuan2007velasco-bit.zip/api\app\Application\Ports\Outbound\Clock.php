<?php

declare(strict_types=1);

namespace App\Application\Ports\Outbound;

/**
 * Puerto Saliente: Reloj del Sistema UTC.
 */
interface Clock extends ClockInterface
{
}
