<?php

declare(strict_types=1);

namespace App\Application\Ports\Inbound;

use App\Application\DTOs\RegisterSaleDTO;

/**
 * Puerto de Entrada (Inbound): Registro atómico e inmutable de ventas.
 * Implementado por UseCases\RegisterSaleUseCase.
 */
interface PlaceSale
{
    public function execute(RegisterSaleDTO $dto): string;
}
